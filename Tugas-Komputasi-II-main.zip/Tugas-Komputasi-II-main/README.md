# Tugas-Komputasi-II
Sydney Rahmah Syafira
3338250001
3B
# Dosen Pengampu 
Bapak Dr.nat.techn Weksi Budiaji, S.Si, M.Sc
# Tugas 
Melakukan Data Iris Di R
